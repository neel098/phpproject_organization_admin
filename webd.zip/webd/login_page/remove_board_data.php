<?php

  $id=$_REQUEST['did'];
    include('../dbcon.php');
    $qry3="DELETE  FROM adminlogin WHERE id=$id";
    $run3=mysqli_query($con,$qry3);
    if($run3==true){
        header('location:remove_board.php');
    }
?>