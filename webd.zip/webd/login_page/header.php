<?php

    if(isset($_SESSION['uid'])){
        echo " ";
    }
    else{
        header('location:../index.php');
    }
    include('../dbcon.php');

    $id=$_SESSION['uid'];
    $qry="SELECT * FROM `adminlogin` WHERE id='$id'";
    $run=mysqli_query($con,$qry);
    $data=mysqli_fetch_assoc($run);
    if(empty($data['image'])){
		$data['image']="..\dataimg\default_profile.png";
	}
?>


<!DOCTYPE html>
<html>
<head>
	<title>Welcome</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<style>
		.profile_image{
			border-radius: 50%;
			width: 9.5%;
			margin-top: -210px;
			margin-left: -6px;
		}
		.profile_name{
			margin-top: -170px;
			margin-left: 125px;
			font-family: 'Times New Roman', Times, serif;
		}
	


		@import url('https://fonts.googleapis.com/css?family=Raleway:300,400');
		body {
		background: #2D3142;
		font-family: 'Raleway', sans-serif;
		overflow-x:hidden;
		}


		/* Heading */

		h1 {
		font-size: 1.5em;
		text-align: center;
		padding: 70px 0 0 0;
		color: #EF8354;
		font-weight: 300;
		letter-spacing: 1px;
		}

		span {
		border: 2px solid #4F5D75;
		padding: 10px;
		}


		/* Layout Styling */

		#container-fluid {
		width: 100%;
		margin: 0 auto;
		padding: 50px 0 150px 0;
		display: flex;
		flex-direction: row;
		flex-wrap: wrap;
		justify-content: center;
		margin-top: -60px;
		}


		/* Button Styles */

		.button {
		display: inline-flex;
		height: 40px;
		width: 150px;
		border: 2px solid #BFC0C0;
		margin: 20px 20px 20px 20px;
		color: #BFC0C0;
		text-transform: uppercase;
		text-decoration: none;
		font-size: .8em;
		letter-spacing: 1.5px;
		align-items: center;
		justify-content: center;
		overflow: hidden;
		}

		a {
		color: #BFC0C0;
		text-decoration: none;
		letter-spacing: 1px;
		}

		#button-5 {
		position: relative;
		overflow: hidden;
		cursor: pointer;
		}

		#button-5 a {
		position: relative;
		transition: all .45s ease-Out;
		}

		#translate {
		transform: rotate(50deg);
		width: 100%;
		height: 250%;
		left: -200px;
		top: -30px;
		background: #BFC0C0;
		position: absolute;
		transition: all .3s ease-Out;
		}

		#button-5:hover #translate {
		left: 0;
		}

		#button-5:hover a {
		color: #2D3142;
		}

		@media screen and (min-width:1000px) {
		h1 {
			font-size: 2.2em;
		}
		#container {
			width: 50%;
		}
		}



	</style>
</head>
<body>
	<div>
	<div style="background-color: lightblue;height: 100px;" class="container-fluid">
			<div><img src="..\image\Yuvaa_Round.png" style="height: 180px;margin-left:1080px;" ></div>
			<div><img src="..\dataimg\<?php echo $data['image'] ?>" class="profile_image"></div>
			<div class="profile_name"><h4>Welocme <br> <?php echo $data['name'];
			
			?> <br> <?php echo date("l"); echo ","; echo date("d,M,Y");	?></h4></div>
	</div>	
</div>





<div id="container-fluid" class="container-fluid">

<div class="button" id="button-5">
    <div id="translate"></div>
    <a href="home.php">Home</a>
  </div>

  <div class="button" id="button-5">
    <div id="translate"></div>
    <a href="profile.php">View My Profile</a>
  </div>


  <div class="button" id="button-5">
    <div id="translate"></div>
    <a href="update_profile.php">Update My Profile</a>
  </div>

  <div class="button" id="button-5">
    <div id="translate"></div>
    <a href="logout.php">Log Out</a>
  </div>

</div>





</body>
</html>