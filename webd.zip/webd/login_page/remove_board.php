<?php
    session_start();
	if(isset($_SESSION['uid'])==1)
	{
		echo "";
	}
	else{
		header('location:../index.php');
	}
	include('../dbcon.php');

	$id=$_SESSION['uid'];

	$qry="SELECT * FROM adminlogin WHERE id='$id'";
	$run=mysqli_query($con,$qry);
	$data=mysqli_fetch_assoc($run);	

	if(empty($data['image'])){
		$data['image']="..\dataimg\default_profile.png";
	}
    include('header.php'); 
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>View Board</title>
	<style>
	
			.main {
		width: 100%;
		height: 100%;
		position: absolute;
		top: 0;
		left: 0;
		overflow: auto;
		}
		.profile {
		background-image: url("http://starkovtattoo.spb.ru/images/200/DSC100224440.png");
		
		background-position: center;
		background-repeat: no-repeat;
		background-size: cover;
		background-color:#444;
		width: 250px;
		height: 400px;
		top: 50%;
		left: 50%;
		
		
		border-radius:24px;
		border:none;
		box-shadow: 0 37.125px 70px -12.125px rgba(0,0,0,0.2);
		transition:all .3s;
		}

		.profileName {
		background:transparent;
		border:0;
		text-align:center;
		font-size:16px;
		font-weight:800;
		color:#eee;
		}



		.card-body {
		color:#eee;
		margin-top:1.5em;
		}
		.avatar {
		border-radius:50%;
		max-width:128px;
		transform: scale(0.95);
		transition:all .5s;
		cursor:pointer;
		}
		.avatar:hover {
		transform: scale(1);
		box-shadow: 0 37.125px 70px -12.125px rgba(0,0,0,0.2);
		}
		.profilePic {
		text-align:center;
		}

		.profileInfo {
		margin-top:1em;
		font-weight:200;
		font-size:12px;
		color:#eee;
		text-align:center;
		}
	</style>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<body>
	
</body>
</html>

<?php  


$qry1="SELECT * FROM adminlogin ";
$run1=mysqli_query($con,$qry1);



while($data1=mysqli_fetch_assoc($run1)){ ?>


	<?php if(empty($data1['image'])){
		$data1['image']="..\dataimg\default_profile.png";
	} ?>

	<div class="card profile container-fluid" style="margin-top:-135px;display:inline-block;
	margin-left:32px;margin-right:30px;">
   
    <div class="card-body profileBody">
      <div class="profilePic">
        <img class="avatar" src="..\dataimg\<?php  echo $data1['image'] ?>" alt="Username">
      </div>
	  <div class="card-header profileName"> <?php  echo $data1['name']; ?>   </div>
	  <div class="profileInfo">
        <p>EMP ID: <?php echo $data1['empid'] ?></p>
      </div>

      <div class="profileInfo">
        <p>Role: <?php echo $data1['designation'] ?></p>
      </div>
	  <div class="profileInfo">
        <p>Date of Joining: <?php echo $data1['joiningdate'] ?></p>
      </div>
	  <div class="profileInfo">
        <p>Mobile: <?php echo $data1['mobile'] ?></p>
      </div>
	  <div class="profileInfo">
        <p>E-Mail: <?php echo $data1['email'] ?></p>
      </div>
      <a href="remove_board_data.php?did=<?php  echo $data1['id']; ?>"
      <button type="button" class="btn btn-danger" style="margin-left:-14px;margin-top:41px;border-radius:24px;
      padding-right:70px;padding-left:70px;">Delete Member</button></a>
    </div>
    </div>
  </div>
  </div>
<?php
}
?>