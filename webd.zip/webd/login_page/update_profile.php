<?php
	
	session_start();
	if(isset($_SESSION['uid']))
	{
		echo "";
	}
	else{
		header('location:../index.php');
	}
	include('../dbcon.php');

	$id=$_SESSION['uid'];

	$qry="SELECT * FROM adminlogin  WHERE id='$id'";
	$run=mysqli_query($con,$qry);
	$data=mysqli_fetch_assoc($run);	

	if(empty($data['image'])){
		$data['image']="dataimg\default_profile.png";
	}
	include('header.php'); 
?>

<html>
<head>
<title>My Profile</title>
<style>
    .vl {
  border-left: 6px solid green;
  height: 280px;
  margin-top:-110px;
  margin-left:30px;
  .fa {
    padding: 10px;
    width: 400px;
  }

  .fa::before {
    display: inline-block;
    /* .fa-fw */
    width: 2.28571429em;
    text-align: center;
  }

  .fa::after {
    content: attr(class);
    font-family: consolas, monospace;
    font-size: 15px;
    /* .code */
    padding: 2px 4px;
    color: #c7254e;
    background-color: #f9f2f4;
    border-radius: 4px;
    margin-left: 5px;
  }
}
</style>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"/>
</head>
<body style="background-color:white;">
  

<form action="update_profile.php" method="post">  
<div style="margin-left:80px">
<div style="display:inline-flex;">
<div style="margin-top:-110px;margin-left:20px;">
<img src="..\dataimg\<?php echo $data['image'] ?>" style="width:33%;height:280px;">

</div>

<div style="margin-left:-524px;margin-top:-130px;max-width:250px;">

<h3>Name: <?php  echo $data['name'] ?></h3>
<div style="margin-left:-00px;margin-top:-2px;">
<h4>Designation: <?php  echo $data['designation'] ?></h4>
</div>
<div style="margin-left:-00px;margin-top:-2px;">
<h4>Employee ID: <?php  echo $data['empid'] ?></h4>
</div>
<div style="margin-left:-00px;margin-top:-2px;">
<h4>Joining Date: <?php  echo $data['joiningdate'] ?></h4>
</div>
<div style="margin-left:-00px;margin-top:-2px;">
<h4>Date of Birth: <input type="text" value="<?php  echo $data['dob'] ?>"></h4>
</div>
<div style="margin-left:-00px;margin-top:-2px;">
<h4>E-Mail: <input type="text" value="<?php  echo $data['email'] ?>"></h4>
</div>
<div style="margin-left:-00px;margin-top:-2px;">
<h4>Mobile: <input type="text" value="<?php  echo $data['mobile'] ?>"></h4>
</div>
<div style="margin-left:-00px;margin-top:-2px;">
<h4>Address: <input type="text" value="<?php  echo $data['address'] ?>"></h4>
</div>
</div>
<div>
<div class="vl"></div>
<div style="margin-left:90px;margin-top:-300px;">
<h2>Connect With Me @</h2>
<div style="display:inline-flex;margin-left:10px;">
<h4 style="margin-right:15px"><a href="<?php echo $data['linkedin'] ?>" target="blank"><i class="fa fa-linkedin"></i></a></h4>
<h4 style="margin-right:15px"><a href="<?php echo $data['fb'] ?>" target="blank"><i class="fa fa-facebook"></i></a></h4>
<h4 style="margin-right:15px"><a href="<?php echo $data['insta'] ?>" target="blank"><i class="fa fa-instagram"></i></a></h4>
<h4 style="margin-right:15px"><a href="<?php echo $data['twitter'] ?>" target="blank"><i class="fa fa-twitter"></i></a></h4>
</div>
</div>
</div>
</div>

</form>
</body>
</html>